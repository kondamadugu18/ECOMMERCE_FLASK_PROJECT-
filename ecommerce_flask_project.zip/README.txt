
E-Commerce Website using Flask & SQLite

Steps to Run:

1. Install Flask
   pip install flask

2. Initialize Database
   python init_db.py

3. Run App
   python app.py

4. Open Browser
   http://127.0.0.1:5000
