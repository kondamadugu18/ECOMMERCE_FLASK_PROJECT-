
from flask import Flask, render_template, request, redirect, url_for, session
import sqlite3

app = Flask(__name__)
app.secret_key = "secret123"

def get_db():
    return sqlite3.connect("database.db")

@app.route("/")
def index():
    con = get_db()
    cur = con.cursor()
    cur.execute("SELECT * FROM products")
    products = cur.fetchall()
    con.close()
    return render_template("index.html", products=products)

@app.route("/add/<int:id>")
def add_to_cart(id):
    if "cart" not in session:
        session["cart"] = []
    session["cart"].append(id)
    return redirect(url_for("index"))

@app.route("/cart")
def cart():
    cart_items = session.get("cart", [])
    con = get_db()
    cur = con.cursor()

    items = []
    total = 0

    for i in cart_items:
        cur.execute("SELECT * FROM products WHERE id=?", (i,))
        item = cur.fetchone()
        if item:
            items.append(item)
            total += item[2]

    con.close()
    return render_template("cart.html", items=items, total=total)

@app.route("/clear")
def clear_cart():
    session.pop("cart", None)
    return redirect(url_for("cart"))

if __name__ == "__main__":
    app.run(debug=True)
