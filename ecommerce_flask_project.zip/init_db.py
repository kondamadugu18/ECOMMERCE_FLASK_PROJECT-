
import sqlite3

con = sqlite3.connect("database.db")
cur = con.cursor()

cur.execute("""
CREATE TABLE IF NOT EXISTS products(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    price INTEGER
)
""")

cur.execute("INSERT INTO products(name,price) VALUES('Laptop',50000)")
cur.execute("INSERT INTO products(name,price) VALUES('Mobile',20000)")
cur.execute("INSERT INTO products(name,price) VALUES('Headphones',3000)")
cur.execute("INSERT INTO products(name,price) VALUES('Keyboard',1500)")

con.commit()
con.close()

print("Database Initialized")
